const Footer = () => {
  return (
    <div
      style={{
        color: "gray",
        marginTop: "10px",
        borderTop: "1px solid #555",
        textAlign: "center",
      }}
    >
      Happy Coding! @ContactOPedia
    </div>
  );
};

export default Footer;
