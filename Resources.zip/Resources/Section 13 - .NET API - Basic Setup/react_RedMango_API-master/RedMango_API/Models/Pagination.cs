﻿namespace RedMango_API.Models
{
    public class Pagination  
    {
        public int CurrentPage { get; set; }
        public int PageSize { get; set; }
        public int TotalRecords { get; set; }
    }
}
