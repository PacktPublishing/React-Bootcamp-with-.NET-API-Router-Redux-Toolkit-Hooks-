import { createAction } from "@reduxjs/toolkit";

export const resetReduxOPedia = createAction("reduxopedia/reset");
