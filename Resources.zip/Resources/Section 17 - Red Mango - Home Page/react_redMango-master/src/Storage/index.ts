import store from "./Redux/store";

export { store };
