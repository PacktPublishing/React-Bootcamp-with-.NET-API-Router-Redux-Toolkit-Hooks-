import React from "react";

function AccessDenied() {
  return <div>AccessDenied</div>;
}

export default AccessDenied;
