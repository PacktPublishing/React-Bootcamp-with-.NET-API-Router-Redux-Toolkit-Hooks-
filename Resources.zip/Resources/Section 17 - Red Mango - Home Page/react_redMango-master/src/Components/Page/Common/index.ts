import MiniLoader from "./MiniLoader";
import Banner from "./Banner";
import MainLoader from "./MainLoader";
export { Banner, MiniLoader, MainLoader };
