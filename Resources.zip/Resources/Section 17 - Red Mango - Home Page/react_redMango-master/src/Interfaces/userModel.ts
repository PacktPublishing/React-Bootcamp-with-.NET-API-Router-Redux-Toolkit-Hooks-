export default interface userModel {
  fullName?: string;
  id: string;
  email: string;
  role?: string;
}
